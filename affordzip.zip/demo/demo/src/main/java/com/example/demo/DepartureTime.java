package com.example.demo;

public class DepartureTime {
    private int Hours;
    private int Minutes;
    private int Seconds;
}
