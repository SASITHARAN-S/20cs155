package com.example.demo;

public class Price {
    private int sleeper;
    private int AC;
}
