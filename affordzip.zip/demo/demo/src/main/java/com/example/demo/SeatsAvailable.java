package com.example.demo;

public class SeatsAvailable {
    private int sleeper;
    private int AC;
}
