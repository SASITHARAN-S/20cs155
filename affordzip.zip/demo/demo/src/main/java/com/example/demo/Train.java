package com.example.demo;


    public class Train {
        private String trainName;
        private String trainNumber;
        private DepartureTime departureTime;
        private SeatsAvailable seatsAvailable;
        private Price price;
        private int delayedBy;

        // Getters and Setters (omitted for brevity)
    }


